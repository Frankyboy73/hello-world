.. _statistics-detail-label:

Statistics Detail
==================
The following are details about each of the counters

.. toctree::
   :maxdepth: 2

   stats/egrBytes.rst
   stats/egrTotal.rst
   stats/ingrBytes.rst
   stats/ingrTotal.rst
   stats/egrPkts.rst
   stats/ingrPkts.rst
   stats/egrDropPkts.rst
   stats/ingrDropPkts.rst
   stats/ingrUnkBytes.rst
   stats/ingrStorm.rst
   stats/ingrUnkPkts.rst


